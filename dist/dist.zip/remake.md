
127.0.0.1:3015/adminLogin  //后台登录页面

127.0.0.1:3015/deskadminLogin //补货台登录页面

127.0.0.1:3015/payqecode //二维码 广告页面